// Aluno : 

/*
 Sintese
   Objetivo: Efetuar o c�lculo de um valor percentual informado 
   pelo usu�rio em cima de um valor constante (555).
 
   Entrada : O valor percentual a ser calculado

   Saida   : O valor final do c�lculo do percentual calculado em
   cima do valor constante. 

*/

#include <stdio.h>
#include <conio.h>
#define VALOR 555

int main(void)
{
// Declaracoes
float PERCENTUAL, RESULTADO;
// Instrucoes
printf ("Informe o percentual a ser calculado:");
scanf ("%f", &PERCENTUAL);
RESULTADO = (PERCENTUAL/100) * 555;
printf ("O resultado eh %.2f", RESULTADO);


  getch();
  return 0;
}
