// Aluno : 

/*
 Sintese
   Objetivo: Desenhar uma moldura de 10 caracteres de altura por
   20 de largura
 
   Entrada : Usando os carateres predefinidos.

   Saida   : A moldura em tela limpa

*/

#include <stdio.h>
#include <conio.c>
#define  VALOR1 BA

int main(void)
{
// Declaracoes
int LINHA, COLUNA;


// Instrucoes
gotoxy(24,11);
printf("\xc9");
for (LINHA=0; LINHA<10; LINHA++)
{
    printf ("\xcd");
    }
printf("\xbb");

  getch();
  return 0;
}
