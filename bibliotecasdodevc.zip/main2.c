// Aluno : 

/*
 Sintese
   Objetivo: Ler tr�s valores num�ricos e mostr�-los em ordem
   crescente no centro de uma janela limpa e com uma moldura em
   volta.
 
   Entrada : Tr�s valores num�ricos; 

   Saida   : Os valores em ordem crescente no centro de uma jane-
   la limpe com uma moldura em volta.

*/

#include <stdio.h>
#include <conio.c>

int main(void)
{
// Declaracoes
int VALOR1, VALOR2, VALOR3;
// Instrucoes
printf ("Informe o primeiro valor:");
scanf ("%d", &VALOR1);
printf ("Informe o segundo valor:");
scanf ("%d", &VALOR2);
printf ("Informe o terceiro valor:");
scanf ("%d", &VALOR3);

if ((VALOR1 <= VALOR2) && (VALOR2 <= VALOR3)){
   clrscr();
   gotoxy(24,11);
   printf ("%d, %d, %d", VALOR1, VALOR2, VALOR3);
}
   else { if ((VALOR2 <= VALOR1) && (VALOR1 <= VALOR3)) {
           clrscr();
           gotoxy(24,11);
           printf ("%d, %d, %d", VALOR2, VALOR1, VALOR3);
           }
           else { if ((VALOR1 <= VALOR3) && (VALOR3 <= VALOR2)) {
                 clrscr();
                 gotoxy(24,11);
                 printf ("%d, %d, %d", VALOR1, VALOR3, VALOR2);
                 }
                 else { if ((VALOR2 >= VALOR3) && (VALOR3 >= VALOR2)) {
                      clrscr();
                      gotoxy(24,11);
                      printf ("%d, %d, %d", VALOR1, VALOR3, VALOR2);
                      }                 
                      else { if ((VALOR2 <= VALOR3) && (VALOR3 <= VALOR1)) {
                             clrscr();
                             gotoxy(24,11);
                             printf ("%d, %d, %d", VALOR2, VALOR3, VALOR1);
                           }
                           else { if ((VALOR3 <= VALOR1) && (VALOR1 <= VALOR2)) {
                                  clrscr();
                                  gotoxy(24,11);
                                  printf ("%d, %d, %d", VALOR3, VALOR1, VALOR2);
                           }
                           else { if ((VALOR3 <= VALOR2) && (VALOR2 <= VALOR1)) {
                                  clrscr();
                                  gotoxy(24,11);
                                  printf ("%d, %d, %d", VALOR3, VALOR1, VALOR2);
                           }
                       }
                    }
                }
           }
      }            
}
  getch();
  return 0;
}
